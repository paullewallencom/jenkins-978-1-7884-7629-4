## How to run ?

1. Create all the machines for each environment using virtual box as default provider.

```
$ vagrant up
```
